OGAgent is the agent intended for OpengGnSys interaction.

Please, visit http://www.opengnsys.es for more information
